In this Project We will study
1. Python Language
2. Django Script
3. HTML and CSS
4. Basic Knowledge of Installation of different Script
5. Basic Knowledge of command prompt code


Django Administration Login 
Username: PythonProject
Password: python@2021
